import { Task } from "@/lib/types";

export default function StatsBar({ tasks }: { tasks: Task[] }) {
  const total = tasks.length;
  const done = tasks.filter((t) => t.completed).length;
  return (
    <div className="flex items-center justify-between card mb-4">
      <div className="text-lg font-semibold">Tasks: {total}</div>
      <div className="text-sm text-gray-600">Completed: {done} of {total}</div>
    </div>
  );
}
