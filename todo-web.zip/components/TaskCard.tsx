"use client";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { deleteTask, updateTask } from "@/lib/api";
import type { Task } from "@/lib/types";
import { colorDot } from "@/lib/types";

export default function TaskCard({ task }: { task: Task }) {
  const router = useRouter();
  const [optimistic, setOptimistic] = useState(task);
  const [isPending, startTransition] = useTransition();

  const toggle = () => {
    const next = { ...optimistic, completed: !optimistic.completed };
    setOptimistic(next);
    startTransition(async () => {
      try {
        await updateTask(task.id, { completed: next.completed });
        router.refresh();
      } catch (e) {
        alert("Failed to update. Please retry.");
        setOptimistic(task);
      }
    });
  };

  const onDelete = async () => {
    if (!confirm("Delete this task?")) return;
    try {
      await deleteTask(task.id);
      router.refresh();
    } catch {
      alert("Failed to delete. Please retry.");
    }
  };

  return (
    <div className={\`card flex items-center gap-3 \${isPending ? "opacity-70" : ""}\`}>
      <label className="inline-flex items-center gap-2 cursor-pointer">
        <input type="checkbox" checked={optimistic.completed} onChange={toggle} className="size-5" aria-label="Toggle complete" />
      </label>
      <span className={\`inline-block size-3 rounded-full \${colorDot(task.color)}\`} aria-hidden />
      <Link href={\`/tasks/\${task.id}\`} className="flex-1">
        <div className={\`font-medium \${optimistic.completed ? "line-through text-gray-500" : ""}\`}>{task.title}</div>
      </Link>
      <button onClick={onDelete} className="btn-ghost text-red-600">Delete</button>
    </div>
  );
}
