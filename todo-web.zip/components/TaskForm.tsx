"use client";
import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";
import { z } from "zod";
import { COLORS, type Task, type Color } from "@/lib/types";
import { createTask, updateTask } from "@/lib/api";

const schema = z.object({
  title: z.string().trim().min(1, "Title is required").max(255),
  color: z.enum(COLORS as unknown as [Color, ...Color[]]),
});

export default function TaskForm({ initial }: { initial?: Partial<Task> }) {
  const r = useRouter();
  const [title, setTitle] = useState(initial?.title ?? "");
  const [color, setColor] = useState<Color>((initial?.color as Color) ?? "gray");
  const [error, setError] = useState<string | null>(null);
  const [isPending, startTransition] = useTransition();
  const isEdit = Boolean(initial?.id);

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    const parsed = schema.safeParse({ title, color });
    if (!parsed.success) return setError(parsed.error.issues[0].message);
    startTransition(async () => {
      try {
        if (isEdit) await updateTask(initial!.id!, { title: parsed.data.title, color: parsed.data.color });
        else await createTask(parsed.data);
        r.push("/");
        r.refresh();
      } catch (err: any) {
        setError(err?.message ?? "Save failed");
      }
    });
  };

  return (
    <form onSubmit={onSubmit} className="card space-y-4">
      <div>
        <label className="block mb-1 text-sm font-medium">Title *</label>
        <input className="input" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="e.g., Ship MVP" disabled={isPending} />
      </div>
      <div>
        <label className="block mb-1 text-sm font-medium">Color</label>
        <select className="select" value={color} onChange={(e) => setColor(e.target.value as Color)} disabled={isPending}>
          {COLORS.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>
      </div>
      {error && <p className="text-sm text-red-600">{error}</p>}
      <div className="flex gap-2">
        <button type="submit" className="btn-primary" disabled={isPending}>{isEdit ? "Update Task" : "Create Task"}</button>
        <button type="button" onClick={() => history.back()} className="btn-ghost" disabled={isPending}>Cancel</button>
      </div>
    </form>
  );
}
