import TaskForm from "@/components/TaskForm";

export default function NewTaskPage() {
  return (
    <div>
      <h1 className="text-2xl font-semibold mb-4">Create Task</h1>
      <TaskForm />
    </div>
  );
}
