export default function Loading() {
  return <div className="card animate-pulse h-24" />;
}
