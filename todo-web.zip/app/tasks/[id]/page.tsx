import TaskForm from "@/components/TaskForm";
import { getTask } from "@/lib/api";
import { notFound } from "next/navigation";

type Params = { params: { id: string } };

export default async function EditTaskPage({ params }: Params) {
  const id = Number(params.id);
  if (!Number.isInteger(id) || id <= 0) notFound();
  try {
    const task = await getTask(id);
    return (
      <div>
        <h1 className="text-2xl font-semibold mb-4">Edit Task</h1>
        <TaskForm initial={task} />
      </div>
    );
  } catch {
    notFound();
  }
}
