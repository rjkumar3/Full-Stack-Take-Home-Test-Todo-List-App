import { getTasks } from "@/lib/api";
import TaskCard from "@/components/TaskCard";
import StatsBar from "@/components/StatsBar";

export default async function Home() {
  const tasks = await getTasks();
  return (
    <div className="space-y-3">
      <StatsBar tasks={tasks} />
      {tasks.map((t) => (<TaskCard key={t.id} task={t} />))}
      {tasks.length === 0 && (
        <div className="card text-center text-gray-600">No tasks yet. Click <span className="font-medium">Create Task</span> to add your first.</div>
      )}
    </div>
  );
}
