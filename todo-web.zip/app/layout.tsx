import "./globals.css";
import Link from "next/link";

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <header className="border-b bg-white">
          <div className="container py-4 flex items-center justify-between">
            <Link href="/" className="text-xl font-semibold">Todo</Link>
            <Link href="/tasks/new" className="btn-primary">Create Task</Link>
          </div>
        </header>
        <main className="container py-6">{children}</main>
      </body>
    </html>
  );
}
