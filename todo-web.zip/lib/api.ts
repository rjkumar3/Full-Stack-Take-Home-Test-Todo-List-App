import type { Task } from "./types";

const BASE = process.env.NEXT_PUBLIC_API_URL!;

export async function getTasks(): Promise<Task[]> {
  const res = await fetch(`${BASE}/tasks`, { cache: "no-store" });
  if (!res.ok) throw new Error("Failed to fetch tasks");
  return res.json();
}

export async function getTask(id: number): Promise<Task> {
  const res = await fetch(`${BASE}/tasks/${id}`, { cache: "no-store" });
  if (!res.ok) throw new Error("Task not found");
  return res.json();
}

export async function createTask(data: { title: string; color: Task["color"] }) {
  const res = await fetch(`${BASE}/tasks`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error("Create failed");
  return res.json();
}

export async function updateTask(id: number, data: Partial<Pick<Task, "title" | "color" | "completed">>) {
  const res = await fetch(`${BASE}/tasks/${id}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error("Update failed");
  return res.json();
}

export async function deleteTask(id: number) {
  const res = await fetch(`${BASE}/tasks/${id}`, { method: "DELETE" });
  if (!res.ok && res.status !== 204) throw new Error("Delete failed");
}
