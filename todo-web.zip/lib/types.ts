export type Task = {
  id: number;
  title: string;
  color: "red" | "green" | "blue" | "yellow" | "purple" | "gray";
  completed: boolean;
  createdAt: string;
  updatedAt: string;
};

export const COLORS = ["red", "green", "blue", "yellow", "purple", "gray"] as const;
export type Color = typeof COLORS[number];

export const colorDot = (c: Color) =>
  ({
    red: "bg-red-500",
    green: "bg-green-500",
    blue: "bg-blue-500",
    yellow: "bg-yellow-500",
    purple: "bg-purple-500",
    gray: "bg-gray-400",
  }[c]);
